//
//  NERAppDelegate.h
//  NeuraAuthSampleApp
//
//  Created by Daniel on 9/15/14.
//  Copyright (c) 2014 Neura. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NERAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
