//
//  main.m
//  NeuraAuthSampleApp
//
//  Created by Daniel on 9/15/14.
//  Copyright (c) 2014 Neura. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "NERAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([NERAppDelegate class]));
    }
}
