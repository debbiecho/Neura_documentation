//
//  NERViewController.h
//  NeuraAuthSampleApp
//
//  Created by Daniel on 9/15/14.
//  Copyright (c) 2014 Neura. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NERViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *label;

@end
