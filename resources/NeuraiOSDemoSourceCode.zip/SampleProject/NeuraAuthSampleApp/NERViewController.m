//
//  NERViewController.m
//  NeuraAuthSampleApp
//
//  Created by Daniel on 9/15/14.
//  Copyright (c) 2014 Neura. All rights reserved.
//

#import "NERViewController.h"
#import "Neura.h"

@interface NERViewController ()
@property (weak, nonatomic) IBOutlet UIButton *auth;

@end

@implementation NERViewController
- (IBAction)startNeuraAuth:(id)sender {
    
    
    [[Neura sharedInstance] setClientId:@"351b465f35f56ae81fb450963c6110711bdb89fae2ee30fe7dfee876705d3a2c"];
    [[Neura sharedInstance] setClientSecretId :@"fc5fff21361d0dde7e6a1fa1558906f36c5c841b58d157cb61208710ccaf27d2" ];
    [[Neura sharedInstance] setPermmisions:@"userIsRunning,userArrivedToSignificantLocationFromActiveZone,userStartedWalking"];

    
    NSError *error = nil;
    [[Neura sharedInstance] AuthenticationWithError:&error];
    if (error) {
        NSLog(@"Error: %@",error.userInfo[@"NSLocalizedDescription"]);
        self.label.text = error.userInfo[@"NSLocalizedDescription"];
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
